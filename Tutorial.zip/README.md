# Kado
-Flower code from: https://codepen.io/mdusmanansari/pen/BamepLe


# How To Use The Files
After downloading the zip files, visit www.replit.com. Create a new Repl under "HTML/CSS/JS".

# index.html
To edit the name of the person, you can visit index.html
I have already created a 5 letter word "hello" if the person name is longer than 5 letters, you will have to do extra work so I suggest just do 5 and below. (line 14 - line 18)

# Card.html
To change background music, just replace "Bg.mp3" file.

To change card cover, just replace "Cover.Png". 
(Currently i'm using a resolution of 1,979px x 2,639px.)

Hopes this helps!           -xd3f4lt